@extends('contacts.layout')
@section('content')
 
<div class="card" style="background-color: darkgreen; margin-top: 150px;">
  <div class="card-header text-center" style="color:aliceblue; font-size:20px;">ADD NEW CONTACT</div>
  <div class="card-body" style="color:aliceblue; font-size:20px;">
      
      <form action="{{ url('contact') }}" method="post">
        {!! csrf_field() !!}
        <label>Complete Name</label></br>
        <input type="text" name="name" id="name" class="form-control"></br>
        <label>Address</label></br>
        <input type="text" name="address" id="address" class="form-control"></br>
        <label>Mobile</label></br>
        <input type="text" name="mobile" id="mobile" class="form-control"></br>
        <input type="submit" value="Save" class="btn" style="background-color: aqua;"></br>
    </form>
   
  </div>
</div>
 
@stop